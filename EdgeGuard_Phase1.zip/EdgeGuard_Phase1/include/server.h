#ifndef EDGE_SERVER_H
#define EDGE_SERVER_H
#include <stddef.h>
void handle_client(int fd);
int build_sysinfo(char *out, size_t capacity);
#endif
