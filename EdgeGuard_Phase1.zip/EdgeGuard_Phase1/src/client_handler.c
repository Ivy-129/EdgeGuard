#include "server.h"
#include "logger.h"
#include "protocol.h"
#include "socket_utils.h"
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
void handle_client(int fd) {
    struct timeval tv = {.tv_sec = 120, .tv_usec = 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof tv);
    char line[EDGE_MAX_LINE];
    for (;;) {
        ssize_t n = edge_recv_line(fd, line, sizeof line);
        if (n == 0) break;
        if (n == -2) {
            if (edge_send_response(fd, 0, "TOO_LONG", "Request exceeds limit\n") < 0) break;
            continue;
        }
        if (n < 0) { edge_log(1, "Client disconnected or read error"); break; }
        edge_log(2, "Request: %s", line);
        if (strcmp(line, "SYSINFO") == 0) {
            char result[1024];
            if (build_sysinfo(result, sizeof result) < 0) {
                if (edge_send_response(fd, 0, "INTERNAL_ERROR", "System info unavailable\n") < 0) break;
            } else if (edge_send_response(fd, 1, NULL, result) < 0) break;
        } else if (strcmp(line, "QUIT") == 0) {
            edge_send_response(fd, 1, NULL, "Goodbye\n");
            break;
        } else if (edge_send_response(fd, 0, "INVALID_COMMAND", "Use SYSINFO or QUIT\n") < 0) break;
    }
}
