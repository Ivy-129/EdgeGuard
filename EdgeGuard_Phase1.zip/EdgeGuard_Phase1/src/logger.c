#include "logger.h"
#include <stdarg.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
static int current_level = 1;
void edge_log_set_level(int level) { current_level = level; }
void edge_log(int level, const char *fmt, ...) {
#ifndef EDGE_DEBUG
    if (level > 1) return;
#endif
    if (level > current_level) return;
    time_t now = time(NULL);
    struct tm tmval;
    localtime_r(&now, &tmval);
    char stamp[32];
    strftime(stamp, sizeof stamp, "%F %T", &tmval);
    fprintf(stderr, "[%s][%s][PID=%ld] ", stamp,
            level == 0 ? "ERROR" : level == 1 ? "INFO" : "DEBUG", (long)getpid());
    va_list args;
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    fputc('\n', stderr);
}
