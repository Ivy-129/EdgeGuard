#include "server.h"
#include "logger.h"
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
static volatile sig_atomic_t stop = 0;
static void on_stop(int sig) { (void)sig; stop = 1; }
static void on_child(int sig) { (void)sig; int saved = errno; while (waitpid(-1, NULL, WNOHANG) > 0) {} errno = saved; }
int main(int argc, char **argv) {
    int port = 8080, level = 1;
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--port") == 0 && i + 1 < argc) port = atoi(argv[++i]);
        else if (strcmp(argv[i], "--log-level") == 0 && i + 1 < argc) level = atoi(argv[++i]);
        else { fprintf(stderr, "Usage: %s [--port 8080] [--log-level 0|1|2]\n", argv[0]); return 1; }
    }
    if (port < 1 || port > 65535 || level < 0 || level > 2) return 1;
    edge_log_set_level(level);
    struct sigaction sa = {0};
    sa.sa_handler = on_child; sigemptyset(&sa.sa_mask); sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;
    sigaction(SIGCHLD, &sa, NULL);
    sa.sa_handler = on_stop; sa.sa_flags = 0;
    sigaction(SIGINT, &sa, NULL); sigaction(SIGTERM, &sa, NULL);
    int listener = socket(AF_INET, SOCK_STREAM, 0);
    if (listener < 0) { perror("socket"); return 1; }
    int one = 1;
    setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    struct sockaddr_in addr = {.sin_family = AF_INET, .sin_port = htons((unsigned short)port), .sin_addr.s_addr = htonl(INADDR_LOOPBACK)};
    if (bind(listener, (struct sockaddr *)&addr, sizeof addr) < 0 || listen(listener, 64) < 0) { perror("bind/listen"); close(listener); return 1; }
    edge_log(1, "Listening on 127.0.0.1:%d", port);
    while (!stop) {
        int fd = accept(listener, NULL, NULL);
        if (fd < 0) { if (errno == EINTR) continue; perror("accept"); break; }
        pid_t pid = fork();
        if (pid < 0) { edge_log(0, "fork failed"); close(fd); continue; }
        if (pid == 0) {
            close(listener);
            edge_log(1, "Handler started");
            handle_client(fd);
            close(fd);
            edge_log(1, "Handler exited");
            _exit(0);
        }
        edge_log(1, "Client connected; handler PID=%ld", (long)pid);
        close(fd);
    }
    close(listener);
    edge_log(1, "Server shutting down (existing handlers exit independently)");
    return 0;
}
